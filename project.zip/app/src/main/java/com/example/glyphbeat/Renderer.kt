package com.example.glyphbeat

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Draws one 25x25 frame for the Glyph Matrix from the analysed audio timeline. */
object Renderer {
    const val N = 25
    val STYLES = arrayOf("Auto (unique per song)", "Pulse + ripples", "Bars", "Radar")

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun render(r: Analyzer.Result, idx0: Int, styleSel: Int): Bitmap {
        val idx = idx0.coerceIn(0, r.size - 1)
        val style = if (styleSel == 0) r.signature % 3 else styleSel - 1
        val bmp = Bitmap.createBitmap(N, N, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.BLACK)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        val cx = N / 2f
        val cy = N / 2f

        when (style) {
            0 -> {
                val b = r.bass[idx]
                p.style = Paint.Style.FILL
                p.alpha = (110 + 145 * b).toInt()
                c.drawCircle(cx, cy, 1.5f + b * 6.5f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.2f
                for (k in 0..18) {
                    val j = idx - k
                    if (j >= 0 && r.beat[j]) {
                        p.alpha = (255 - k * 13).coerceIn(0, 255)
                        c.drawCircle(cx, cy, 3f + k * 0.6f, p)
                    }
                }
            }
            1 -> {
                p.style = Paint.Style.FILL
                for (i in 0..8) {
                    val j = (idx - abs(i - 4) * 2).coerceAtLeast(0)
                    val w = i / 8f
                    val v = if (w < 0.5f) lerp(r.bass[j], r.mid[j], w * 2)
                    else lerp(r.mid[j], r.high[j], (w - 0.5f) * 2)
                    val h = 1.5f + v * 21f
                    val x = 2.2f + i * 2.5f
                    p.alpha = (140 + 115 * v).toInt()
                    c.drawRect(x - 0.8f, cy - h / 2, x + 0.8f, cy + h / 2, p)
                }
            }
            else -> {
                val ang = idx * 0.09
                val len = 4f + r.bass[idx] * 8f
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.4f
                for (t in 0..3) {
                    val a = ang - t * 0.18
                    p.alpha = 255 - t * 65
                    c.drawLine(cx, cy, cx + len * cos(a).toFloat(), cy + len * sin(a).toFloat(), p)
                }
                p.style = Paint.Style.FILL
                for (i in 0 until 12) {
                    val a = i * Math.PI * 2 / 12
                    val j = (idx - i * 2).coerceAtLeast(0)
                    p.alpha = (40 + 215 * r.high[j]).toInt()
                    c.drawCircle(cx + (10.5 * cos(a)).toFloat(), cy + (10.5 * sin(a)).toFloat(), 1.2f, p)
                }
                var flash = false
                for (k in 0..2) if (idx - k >= 0 && r.beat[idx - k]) flash = true
                if (flash) {
                    p.alpha = 255
                    c.drawCircle(cx, cy, 3f, p)
                }
            }
        }
        return bmp
    }
}
