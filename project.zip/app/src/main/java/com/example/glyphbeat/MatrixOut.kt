package com.example.glyphbeat

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixFrame
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphMatrixObject

/** Thin wrapper around Nothing's Glyph Matrix SDK for Phone (3). */
class MatrixOut(private val ctx: Context) {
    private var gm: GlyphMatrixManager? = null
    @Volatile
    var ready = false
        private set

    fun start() {
        try {
            val m = GlyphMatrixManager.getInstance(ctx)
            gm = m
            m.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(name: ComponentName?) {
                    try {
                        m.register(Glyph.DEVICE_23112)
                        ready = true
                    } catch (e: Throwable) {
                    }
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    ready = false
                }
            })
        } catch (e: Throwable) {
        }
    }

    fun show(bmp: Bitmap) {
        if (!ready) return
        try {
            val ob = GlyphMatrixObject.Builder()
            ob.setImageSource(bmp)
            ob.setScale(100)
            ob.setOrientation(0)
            ob.setPosition(0, 0)
            val obj = ob.build()
            val fb = GlyphMatrixFrame.Builder()
            fb.addTop(obj)
            // build() takes a Context in some SDK versions and nothing in others
            val bm = fb.javaClass.methods.first { it.name == "build" }
            val frame = if (bm.parameterTypes.isEmpty()) bm.invoke(fb) else bm.invoke(fb, ctx)
            val ints = frame!!.javaClass.getMethod("render").invoke(frame) as IntArray
            gm?.setAppMatrixFrame(ints)
        } catch (e: Throwable) {
        }
    }

    fun clear() {
        try { if (ready) gm?.closeAppMatrix() } catch (e: Throwable) { }
    }

    fun stop() {
        clear()
        try { gm?.unInit() } catch (e: Throwable) { }
        ready = false
    }
}
