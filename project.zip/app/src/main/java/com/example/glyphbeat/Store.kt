package com.example.glyphbeat

import android.content.Context
import android.net.Uri

/** Keeps the analysed song in memory; re-analyses when a different file is picked. */
object Store {
    @Volatile var result: Analyzer.Result? = null
    @Volatile var analyzedUri: String? = null

    fun uri(ctx: Context): String? =
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("uri", null)

    /** Calls [done] on a background thread (or immediately if cached). */
    fun ensure(ctx: Context, done: (Analyzer.Result?, String?) -> Unit) {
        val u = uri(ctx)
        if (u == null) { done(null, "No song picked yet"); return }
        val cached = result
        if (cached != null && analyzedUri == u) { done(cached, null); return }
        val app = ctx.applicationContext
        Thread {
            try {
                val r = Analyzer.analyze(app, Uri.parse(u))
                result = r
                analyzedUri = u
                done(r, null)
            } catch (e: Throwable) {
                done(null, e.message ?: e.javaClass.simpleName)
            }
        }.start()
    }
}
